﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class WayPointPatrol : MonoBehaviour
{
    //get a NavMeshAgent object
	NavMeshAgent NMA;
    //array of gameobjects for waypoints
	public GameObject[] Waypoints;
	// Use this for initialization
	void Start () 
	{
		NMA = GetComponent<NavMeshAgent> ();
		if (Waypoints.Length == 0)
		{
			Waypoints = GameObject.FindGameObjectsWithTag ("WayPoint");
		}
		NMA.SetDestination (Waypoints [Random.Range (0, Waypoints.Length)].transform.position);
	}

	// Update is called once per frame
	void Update ()
	{
		if (Vector3.Distance (this.gameObject.transform.position, Waypoints [Random.Range (0, Waypoints.Length)].transform.position) <= 1)
		{
			print ("Im Going to " + Waypoints [Random.Range (0, Waypoints.Length)]);
			Patrol ();
		}
		
	}
	void Patrol()
	{
            //chooses a random waypoint from the array and it goes to it
			NMA.SetDestination (Waypoints [Random.Range (0, Waypoints.Length)].transform.position);
	}
}