﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;
using UnityEngine;

public class myAI : MonoBehaviour
{
	public int throwPower = 5;
	public float AttackRange = 1f;
	public Rigidbody Bullet;
	public float Vision = 15;
	public GameObject ShootEndPoint;
	public GameObject Target;

	public GameObject ground;
	public GameObject Alert;
	public GameObject AttackObject;
	public GameObject Question;
	public GameObject Eye1;
	public GameObject Eye2;
	public LayerMask activeLayers;

	public string State ="Wander";
	NavMeshAgent NMA;
	MeshCollider Mesh;


	// Use this for initialization
	void Start ()
	{
        //three gameobjects that let the player know what state the ai is in.
		Alert.SetActive (false);
		AttackObject.SetActive (false);
		Question.SetActive (true);
        //get the NavMeshAgent
        NMA = GetComponent<NavMeshAgent> ();
		//NMA.SetDestination (new Vector3 (Random.Range (Mesh.bounds.min.x, Mesh.bounds.max.x), 0f, Random.Range (Mesh.bounds.min.z, Mesh.bounds.max.z)));
        //on start set the state to wander
		State ="Wander";
	}
	
	// Update is called once per frame
	void Update ()
	{
        //shows the rays in the scene view
		Debug.DrawRay (Eye1.transform.position, Eye1.transform.forward * Vision, Color.blue);
		Debug.DrawRay (Eye2.transform.position, Eye2.transform.forward * Vision, Color.blue);
        //these if's say if the string veriable changes then it runs the method needed
		if (State == "Wander") 
		{
			Wander ();
		}
		if ( State == "Attack") 
		{
			Attack ();
		}
		if (State == "Chase") 
		{
			print ("I SAW TARGET!");
			Chase ();
		}
        //go back to wander if they lost the target
		if (Eye1canSeeTarget () == false && Eye2canSeeTarget() == false && Vector3.Distance (gameObject.transform.position, NMA.destination) >= Vision) 
		{
			State = "Wander";
		}
        //calls the eye methods
		Eye1canSeeTarget ();
		print (Eye1canSeeTarget());
		Eye2canSeeTarget ();
		print (Eye2canSeeTarget());
		//Chase ();
		//InvokeRepeating("Attack", 2.0f, 0.9f);
		//Attack ();

	}


	public void Wander ()
	{

		NMA = GetComponent<NavMeshAgent> ();
        //gets the mesh of the ground
		Mesh = ground.GetComponent<MeshCollider> ();

		Alert.SetActive(false);
		AttackObject.SetActive (false);
		Question.SetActive (true);
        
            //gets the ground mesh and picks a random point to go to and if it gets 2 units close it will find a new random point
			if (Vector3.Distance (gameObject.transform.position, NMA.destination) <= 2)
			{
				NMA.SetDestination (new Vector3 (Random.Range (Mesh.bounds.min.x , Mesh.bounds.max.x) , 0f,  Random.Range ( Mesh.bounds.min.z , Mesh.bounds.max.z )));
				print (NMA.destination);
				State = "Wander";
			}
		    else if(Eye1canSeeTarget () || Eye2canSeeTarget() && State == "Wander")
			{
			print (gameObject.transform.position);
				State = "Chase";
			}

		
	}



	public void Chase()
	{
		NMA = GetComponent<NavMeshAgent> ();
		Alert.SetActive(true);
		AttackObject.SetActive (false);
		Question.SetActive (false);
	
        //chases the target
		NMA.SetDestination (Target.transform.position);

        //checks if it is close enough to the target to attack, if not it continues chasing it
		if (Vector3.Distance (gameObject.transform.position, Target.transform.position) <= AttackRange && Eye1canSeeTarget() && Eye2canSeeTarget())
		{
			State = "Attack";
		}
		else 
		{
			State = "Chase";
		}
	}
	public void Attack()
	{
        //chases target
		NMA.SetDestination (Target.transform.position);
		//Invoke("Shoot", 1f);
		Alert.SetActive(false);
		AttackObject.SetActive (true);
		Question.SetActive (false);
        //it calls the shoot method so it can attack the target
		Shoot ();
        //if the target gets out of the attack range then it returns to chaseing it
		if (Vector3.Distance (gameObject.transform.position, Target.transform.position) >= AttackRange)
		{
			State = "Chase";
		}
	}
	public void Shoot()
	{
        //makes a rigidbody and assigns it to the instantiated bullet
		Rigidbody clone = Instantiate (Bullet, ShootEndPoint.transform.position, transform.rotation) as Rigidbody;
        //adds force to the rigidbody the was crated so the bullet goes forward
		clone.velocity = transform.TransformDirection (Vector3.forward * throwPower);
		print ("Shot Bullet");
	}

	public bool Eye1canSeeTarget()
	{
        //a ray the shoots and the method returns true if it hits an active layer
		Ray ray1 = new Ray (Eye1.transform.position, Eye1.transform.forward);
		return Physics.Raycast (ray1, Vision, activeLayers);

	}
	public bool Eye2canSeeTarget()
	{
        //a ray the shoots and the method returns true if it hits an active layer
        Ray ray2 = new Ray (Eye2.transform.position, Eye2.transform.forward);
		return Physics.Raycast (ray2, Vision, activeLayers);

	}
}