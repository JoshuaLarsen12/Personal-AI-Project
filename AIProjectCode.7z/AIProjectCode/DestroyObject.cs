﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObject : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		Invoke ("Destroy", 1.5f);
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}
	void Destroy()
	{
		GameObject.Destroy (this.gameObject);
	}
}
