﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class WanderAI : MonoBehaviour 
{
	public GameObject ground;
	NavMeshAgent NMA;
	MeshCollider Mesh;
	public float SheildDist = 6f;
	public GameObject Enemy;
	public GameObject Sheild;
	public GameObject HappyFace;
	// Use this for initialization
	void Start ()
	{
		HappyFace.SetActive (true);
	}
	
	// Update is called once per frame
	void Update () 
	{
		Defend ();

		if (true)
		{
			NMA = GetComponent<NavMeshAgent> ();
			Mesh = ground.GetComponent<MeshCollider> ();

            if (Vector3.Distance(this.gameObject.transform.position, NMA.destination) <= 1)
            {
                NMA.SetDestination(new Vector3(Random.Range(Mesh.bounds.min.x, Mesh.bounds.max.x), 0f, Random.Range(Mesh.bounds.min.z, Mesh.bounds.max.z)));
                print(NMA.destination);
            }
		}
	}

	void Defend()
	{
		if (Vector3.Distance (this.gameObject.transform.position, Enemy.transform.position) <= SheildDist)
        {
			Sheild.SetActive (true);
			HappyFace.SetActive (false);
		}
        else 
		{
			HappyFace.SetActive (true);
			Sheild.SetActive (false);
		}
	}

}
